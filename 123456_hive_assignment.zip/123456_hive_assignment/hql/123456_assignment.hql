-- =====================================================================================
-- DSC613 Big Data Analytics Assignment
-- Large-Scale Data Analysis Using Apache Hive and Visualization
--
-- Name      : Gayathri Suresh
-- Roll No.  : 123456
-- Script    : hql/123456_assignment.hql
-- Engine    : Apache Hive 2.3.9 CLI, MapReduce execution engine (local mode),
--             embedded Derby metastore, warehouse on the local file system
-- Run       : cd ~/123456_hive_assignment && hive -f hql/123456_assignment.hql
--
-- The script runs top to bottom on a fresh installation. Re-running it is safe:
-- tables are dropped/overwritten before they are rebuilt, so rows are never loaded twice.
-- Lines starting with "-- @output" name the file in outputs/ that holds the result of
-- the statements that follow (scripts/capture_outputs.sh uses them).
-- =====================================================================================

-- -------------------------------------------------------------------------------------
-- Paths: the only two lines a marker needs to change (see README, section 5)
-- -------------------------------------------------------------------------------------
SET hivevar:csv_path=/home/gayathri/123456_hive_assignment/data/ecommerce_transactions.csv;
SET hivevar:export_dir=/home/gayathri/123456_hive_assignment/outputs/exports;

-- Session settings
--   print.header                : print column names with every result
--   use.unique.column.names     : headers read "city", not "t.city"
--   strict.checks.cartesian     : C13, C18 and C19 join a ONE-ROW subquery of averages
SET hive.cli.print.header=true;
SET hive.resultset.use.unique.column.names=false;
SET hive.strict.checks.cartesian.product=false;

-- =====================================================================================
-- PART A : HIVE ENVIRONMENT SETUP
-- =====================================================================================

-- A1. Create the database ecommerce_analytics and switch to it
CREATE DATABASE IF NOT EXISTS ecommerce_analytics
COMMENT 'DSC613 e-commerce transaction analysis';
USE ecommerce_analytics;

-- @output A1_show_databases.txt
SHOW DATABASES;

-- @output A1_hive_version.txt
SELECT version() AS hive_version;
SET hive.execution.engine;

-- A2. Raw table: one column per CSV field, typed so that every value in the file survives the load.
--     INT (not TINYINT) for age: out-of-range ages such as 999 must load as numbers so Part B can
--     find them; TINYINT (max 127) would silently turn 150 and 999 into NULL.
--     DECIMAL(10,2) for unit_price: money needs exact arithmetic; DOUBLE would add rounding error
--     to SUM(quantity * unit_price) on billions of rows.
--     DATE for transaction_date: the file already uses yyyy-MM-dd, Hive's native DATE format.
-- @output A2_describe_raw.txt
DROP TABLE IF EXISTS transactions_raw;
CREATE TABLE IF NOT EXISTS transactions_raw (
    transaction_id    STRING,
    transaction_date  DATE,
    customer_id       STRING,
    customer_age      INT,
    gender            STRING,
    city              STRING,
    product_category  STRING,
    product           STRING,
    quantity          INT,
    unit_price        DECIMAL(10,2),
    payment_method    STRING,
    order_status      STRING,
    customer_rating   INT,
    delivery_days     INT
)
COMMENT 'Raw e-commerce transactions loaded as supplied'
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE
TBLPROPERTIES ('skip.header.line.count'='1');
DESCRIBE transactions_raw;

-- A3. Load the CSV. LOCAL means the path is on the client's local file system and the file is
--     COPIED into the table's warehouse directory (without LOCAL the path is in HDFS and the
--     file is MOVED). OVERWRITE replaces earlier loads so a re-run never duplicates rows.
-- @output A3_load_data.txt
LOAD DATA LOCAL INPATH '${hivevar:csv_path}'
OVERWRITE INTO TABLE transactions_raw;

-- A4. First 10 rows
-- @output A4_first_10_rows.txt
SELECT *
FROM transactions_raw
LIMIT 10;

-- A4b. Load-problem check: non-NULL values per column. A typed column that failed to parse
--      (wrong delimiter or type) would show 0 here.
-- @output A4b_non_null_per_column.txt
SELECT
    COUNT(*)                AS total_rows,
    COUNT(transaction_id)   AS transaction_id,
    COUNT(transaction_date) AS transaction_date,
    COUNT(customer_id)      AS customer_id,
    COUNT(customer_age)     AS customer_age,
    COUNT(gender)           AS gender,
    COUNT(city)             AS city,
    COUNT(product_category) AS product_category,
    COUNT(product)          AS product,
    COUNT(quantity)         AS quantity,
    COUNT(unit_price)       AS unit_price,
    COUNT(payment_method)   AS payment_method,
    COUNT(order_status)     AS order_status,
    COUNT(customer_rating)  AS customer_rating,
    COUNT(delivery_days)    AS delivery_days
FROM transactions_raw;

-- A5. Row count (the CSV has 15,001 lines including the header)
-- @output A5_row_count.txt
SELECT COUNT(*) AS row_count
FROM transactions_raw;

-- A6. Table metadata: table type, location, input format
-- @output A6_describe_formatted_raw.txt
DESCRIBE FORMATTED transactions_raw;

-- A7. Type checks: one numeric comparison, one date function, one string function
-- @output A7a_numeric_check.txt
SELECT
    COUNT(*)                                             AS total_rows,
    SUM(CASE WHEN unit_price > 10000 THEN 1 ELSE 0 END)  AS rows_unit_price_above_10000,
    MIN(unit_price)                                      AS min_unit_price,
    MAX(unit_price)                                      AS max_unit_price
FROM transactions_raw;

-- @output A7b_date_check.txt
SELECT
    MIN(transaction_date)                                       AS first_date,
    MAX(transaction_date)                                       AS last_date,
    DATEDIFF(MAX(transaction_date), MIN(transaction_date)) + 1  AS days_covered,
    YEAR(MIN(transaction_date))                                 AS first_year,
    YEAR(MAX(transaction_date))                                 AS last_year
FROM transactions_raw;

-- @output A7c_string_check.txt
SELECT
    SUBSTR(customer_id, 1, 4)  AS id_prefix,
    LENGTH(customer_id)        AS id_length,
    COUNT(*)                   AS row_count
FROM transactions_raw
GROUP BY SUBSTR(customer_id, 1, 4), LENGTH(customer_id);

-- =====================================================================================
-- PART B : DATA EXPLORATION AND CLEANING
-- =====================================================================================

-- B1. Total records (must equal A5)
-- @output B1_total_records.txt
SELECT COUNT(*) AS total_records
FROM transactions_raw;

-- B2. Missing values in every column. Numeric/date blanks load as NULL; STRING blanks load as
--     '' (empty string), so string columns test NULL, empty AND whitespace-only (TRIM = '').
--     One pass over the table; LATERAL VIEW stack() turns the 14 counts into 14 rows.
-- @output B2_missing_values.txt
SELECT
    x.column_name,
    x.missing_values,
    ROUND(100 * x.missing_values / s.total_rows, 2) AS pct_missing
FROM (
    SELECT
        COUNT(*) AS total_rows,
        SUM(CASE WHEN transaction_id   IS NULL OR TRIM(transaction_id)   = '' THEN 1 ELSE 0 END) AS m01,
        SUM(CASE WHEN transaction_date IS NULL                                THEN 1 ELSE 0 END) AS m02,
        SUM(CASE WHEN customer_id      IS NULL OR TRIM(customer_id)      = '' THEN 1 ELSE 0 END) AS m03,
        SUM(CASE WHEN customer_age     IS NULL                                THEN 1 ELSE 0 END) AS m04,
        SUM(CASE WHEN gender           IS NULL OR TRIM(gender)           = '' THEN 1 ELSE 0 END) AS m05,
        SUM(CASE WHEN city             IS NULL OR TRIM(city)             = '' THEN 1 ELSE 0 END) AS m06,
        SUM(CASE WHEN product_category IS NULL OR TRIM(product_category) = '' THEN 1 ELSE 0 END) AS m07,
        SUM(CASE WHEN product          IS NULL OR TRIM(product)          = '' THEN 1 ELSE 0 END) AS m08,
        SUM(CASE WHEN quantity         IS NULL                                THEN 1 ELSE 0 END) AS m09,
        SUM(CASE WHEN unit_price       IS NULL                                THEN 1 ELSE 0 END) AS m10,
        SUM(CASE WHEN payment_method   IS NULL OR TRIM(payment_method)   = '' THEN 1 ELSE 0 END) AS m11,
        SUM(CASE WHEN order_status     IS NULL OR TRIM(order_status)     = '' THEN 1 ELSE 0 END) AS m12,
        SUM(CASE WHEN customer_rating  IS NULL                                THEN 1 ELSE 0 END) AS m13,
        SUM(CASE WHEN delivery_days    IS NULL                                THEN 1 ELSE 0 END) AS m14
    FROM transactions_raw
) s
LATERAL VIEW stack(14,
    'transaction_id',   s.m01, 'transaction_date', s.m02, 'customer_id',     s.m03,
    'customer_age',     s.m04, 'gender',           s.m05, 'city',            s.m06,
    'product_category', s.m07, 'product',          s.m08, 'quantity',        s.m09,
    'unit_price',       s.m10, 'payment_method',   s.m11, 'order_status',    s.m12,
    'customer_rating',  s.m13, 'delivery_days',    s.m14
) x AS column_name, missing_values;

-- B2b. Missing rating / delivery time split by order status. A blank on a Cancelled order is
--      expected (nothing was delivered); a blank on a Completed or Returned order is a data problem.
-- @output B2b_missing_by_status.txt
SELECT
    order_status,
    COUNT(*)                                                     AS order_count,
    SUM(CASE WHEN customer_rating IS NULL THEN 1 ELSE 0 END)     AS rating_missing,
    SUM(CASE WHEN delivery_days   IS NULL THEN 1 ELSE 0 END)     AS delivery_days_missing
FROM transactions_raw
GROUP BY order_status
ORDER BY order_status;

-- B3. Invalid values: one count per rule (one pass, stack() again for a readable list).
--     Rules 1-5 are the brief's; rules 6-9 are extra consistency checks.
-- @output B3_invalid_value_counts.txt
SELECT x.rule_no, x.rule_description, x.rows_violating
FROM (
    SELECT
        SUM(CASE WHEN customer_age < 18 OR customer_age > 100 THEN 1 ELSE 0 END)                AS r1,
        SUM(CASE WHEN customer_rating < 1 OR customer_rating > 5 THEN 1 ELSE 0 END)             AS r2,
        SUM(CASE WHEN quantity < 1 OR quantity > 5 THEN 1 ELSE 0 END)                           AS r3,
        SUM(CASE WHEN unit_price <= 0 THEN 1 ELSE 0 END)                                        AS r4,
        SUM(CASE WHEN order_status IN ('Completed','Returned') AND delivery_days < 1
                 THEN 1 ELSE 0 END)                                                             AS r5,
        SUM(CASE WHEN order_status = 'Cancelled'
                  AND (delivery_days IS NOT NULL OR customer_rating IS NOT NULL)
                 THEN 1 ELSE 0 END)                                                             AS r6,
        SUM(CASE WHEN transaction_date < '2024-01-01' OR transaction_date > '2025-12-31'
                 THEN 1 ELSE 0 END)                                                             AS r7,
        SUM(CASE WHEN customer_id NOT RLIKE '^CUST[0-9]{5}$' THEN 1 ELSE 0 END)                 AS r8,
        COUNT(transaction_id) - COUNT(DISTINCT transaction_id)                                  AS r9
    FROM transactions_raw
) s
LATERAL VIEW stack(9,
    1, 'customer_age outside 18-100',                       s.r1,
    2, 'customer_rating outside 1-5',                       s.r2,
    3, 'quantity outside 1-5',                              s.r3,
    4, 'unit_price zero or negative',                       s.r4,
    5, 'delivery_days < 1 on a delivered order',            s.r5,
    6, 'Cancelled order with a rating or delivery time',    s.r6,
    7, 'transaction_date outside 2024-01-01 to 2025-12-31', s.r7,
    8, 'customer_id not CUST + 5 digits',                   s.r8,
    9, 'duplicate transaction_id',                          s.r9
) x AS rule_no, rule_description, rows_violating;

-- B3 samples: offending rows for each rule that returned rows
-- @output B3a_sample_invalid_age.txt
SELECT transaction_id, customer_id, customer_age, city, order_status
FROM transactions_raw
WHERE customer_age < 18 OR customer_age > 100
ORDER BY transaction_id
LIMIT 5;

-- @output B3b_sample_invalid_rating.txt
SELECT transaction_id, product, order_status, customer_rating
FROM transactions_raw
WHERE customer_rating < 1 OR customer_rating > 5
ORDER BY transaction_id
LIMIT 5;

-- @output B3c_sample_invalid_delivery.txt
SELECT transaction_id, city, order_status, delivery_days
FROM transactions_raw
WHERE order_status IN ('Completed','Returned') AND delivery_days < 1
ORDER BY transaction_id
LIMIT 5;

-- B4. Distinct values with counts. Values are wrapped in quotes so that blanks ("") and
--     leading/trailing spaces are visible; NULL would print as NULL.
-- @output B4a_distinct_gender.txt
SELECT CONCAT('"', gender, '"') AS gender_value, COUNT(*) AS row_count
FROM transactions_raw
GROUP BY gender
ORDER BY gender_value;

-- @output B4b_distinct_city.txt
SELECT CONCAT('"', city, '"') AS city_value, COUNT(*) AS row_count
FROM transactions_raw
GROUP BY city
ORDER BY city_value;

-- @output B4c_distinct_payment_method.txt
SELECT CONCAT('"', payment_method, '"') AS payment_method_value, COUNT(*) AS row_count
FROM transactions_raw
GROUP BY payment_method
ORDER BY payment_method_value;

-- @output B4d_distinct_order_status.txt
SELECT CONCAT('"', order_status, '"') AS order_status_value, COUNT(*) AS row_count
FROM transactions_raw
GROUP BY order_status
ORDER BY order_status_value;

-- B4e. Product and category text: counts, and products that appear under more than one category
-- @output B4e_product_category_check.txt
SELECT
    p.distinct_products,
    p.distinct_categories,
    m.products_in_multiple_categories
FROM (
    SELECT COUNT(DISTINCT product) AS distinct_products,
           COUNT(DISTINCT product_category) AS distinct_categories
    FROM transactions_raw
) p
CROSS JOIN (
    SELECT COUNT(*) AS products_in_multiple_categories
    FROM (
        SELECT product, COUNT(DISTINCT product_category) AS n_categories
        FROM transactions_raw
        GROUP BY product
    ) x
    WHERE x.n_categories > 1
) m;

-- B5. Unique customers. GROUP BY in a subquery instead of COUNT(DISTINCT ...): the distinct step
--     is spread over many reducers instead of funnelling every customer_id through one.
-- @output B5_unique_customers.txt
SELECT
    COUNT(*)                         AS unique_customers,
    SUM(n_orders)                    AS total_orders,
    ROUND(SUM(n_orders) / COUNT(*), 2) AS avg_orders_per_customer,
    MAX(n_orders)                    AS max_orders_one_customer
FROM (
    SELECT customer_id, COUNT(*) AS n_orders
    FROM transactions_raw
    GROUP BY customer_id
) c;

-- B6. transaction_value = quantity * unit_price over ALL statuses: this profiles the size of
--     every order placed, so outliers are checked on every row, not only on Completed ones.
-- @output B6_transaction_value_stats.txt
SELECT
    MIN(quantity * unit_price)            AS min_transaction_value,
    MAX(quantity * unit_price)            AS max_transaction_value,
    ROUND(AVG(quantity * unit_price), 2)  AS avg_transaction_value
FROM transactions_raw;

-- B7. Treatment decisions (full table with reasons in the report, section 6)
--   customer_age     NULL (516)                 keep row, leave NULL -> age band 'Unknown'
--   customer_age     outside 18-100 (12)        keep row, set NULL   -> age band 'Unknown'
--   gender           blank (324)                replace with 'Unknown'
--   gender           'M' / 'F' (26)             standardise to 'Male' / 'Female'
--   city             blank (142)                replace with 'Unknown'
--   city             UPPER / lower case (36)    TRIM + INITCAP(LOWER()) -> 14 city names
--   payment_method   blank (196)                replace with 'Unknown'
--   customer_rating  outside 1-5 (7)            set NULL (never 0)
--   customer_rating  NULL on Cancelled (1,078)  legitimate, keep NULL
--   customer_rating  NULL on delivered (1,113)  keep row, keep NULL; excluded from averages
--   delivery_days    < 1 on delivered (10)      set NULL
--   delivery_days    NULL on Cancelled (1,078)  legitimate, keep NULL
--   delivery_days    NULL on delivered (130)    keep row, keep NULL; excluded from averages
--   all STRING cols  -                          TRIM() everywhere, so stray spaces cannot split groups
--   No row is dropped.

-- B8. Cleaned table (TABLE, not view: see B10), stored as ORC, with transaction_value added
-- @output B8a_create_clean.txt
DROP TABLE IF EXISTS transactions_clean;
CREATE TABLE transactions_clean
COMMENT 'Cleaned transactions with transaction_value; used by every query in Parts C and D'
STORED AS ORC
AS
SELECT
    TRIM(transaction_id)                                               AS transaction_id,
    transaction_date,
    UPPER(TRIM(customer_id))                                           AS customer_id,
    CASE WHEN customer_age BETWEEN 18 AND 100 THEN customer_age END    AS customer_age,
    CASE
        WHEN gender IS NULL OR TRIM(gender) = ''         THEN 'Unknown'
        WHEN LOWER(TRIM(gender)) IN ('m', 'male')        THEN 'Male'
        WHEN LOWER(TRIM(gender)) IN ('f', 'female')      THEN 'Female'
        WHEN LOWER(TRIM(gender)) IN ('o', 'other')       THEN 'Other'
        ELSE TRIM(gender)          -- unexpected values stay visible for the B9 check
    END                                                                AS gender,
    CASE
        WHEN city IS NULL OR TRIM(city) = ''             THEN 'Unknown'
        ELSE INITCAP(LOWER(TRIM(city)))
    END                                                                AS city,
    TRIM(product_category)                                             AS product_category,
    TRIM(product)                                                      AS product,
    quantity,
    unit_price,
    CASE
        WHEN payment_method IS NULL OR TRIM(payment_method) = '' THEN 'Unknown'
        WHEN LOWER(TRIM(payment_method)) = 'credit card'         THEN 'Credit Card'
        WHEN LOWER(TRIM(payment_method)) = 'debit card'          THEN 'Debit Card'
        WHEN LOWER(TRIM(payment_method)) = 'upi'                 THEN 'UPI'
        WHEN LOWER(TRIM(payment_method)) = 'cash'                THEN 'Cash'
        WHEN LOWER(TRIM(payment_method)) = 'net banking'         THEN 'Net Banking'
        ELSE TRIM(payment_method)
    END                                                                AS payment_method,
    CASE
        WHEN LOWER(TRIM(order_status)) = 'completed'             THEN 'Completed'
        WHEN LOWER(TRIM(order_status)) = 'cancelled'             THEN 'Cancelled'
        WHEN LOWER(TRIM(order_status)) = 'returned'              THEN 'Returned'
        ELSE TRIM(order_status)
    END                                                                AS order_status,
    CASE WHEN customer_rating BETWEEN 1 AND 5 THEN customer_rating END AS customer_rating,
    CASE WHEN delivery_days >= 1 THEN delivery_days END                AS delivery_days,
    CAST(quantity * unit_price AS DECIMAL(12,2))                       AS transaction_value
FROM transactions_raw;

-- @output B8b_describe_clean.txt
DESCRIBE transactions_clean;

-- B9. Validation: re-run the B2, B3 and B4 checks on transactions_clean
-- @output B9a_missing_values_clean.txt
SELECT
    x.column_name,
    x.missing_or_unknown
FROM (
    SELECT
        SUM(CASE WHEN customer_age    IS NULL      THEN 1 ELSE 0 END) AS m1,
        SUM(CASE WHEN gender          = 'Unknown'  THEN 1 ELSE 0 END) AS m2,
        SUM(CASE WHEN city            = 'Unknown'  THEN 1 ELSE 0 END) AS m3,
        SUM(CASE WHEN payment_method  = 'Unknown'  THEN 1 ELSE 0 END) AS m4,
        SUM(CASE WHEN customer_rating IS NULL      THEN 1 ELSE 0 END) AS m5,
        SUM(CASE WHEN delivery_days   IS NULL      THEN 1 ELSE 0 END) AS m6,
        SUM(CASE WHEN TRIM(gender) = '' OR TRIM(city) = '' OR TRIM(payment_method) = ''
                   OR TRIM(product) = '' OR TRIM(product_category) = '' OR TRIM(order_status) = ''
                 THEN 1 ELSE 0 END)                                   AS m7,
        SUM(CASE WHEN transaction_value IS NULL    THEN 1 ELSE 0 END) AS m8
    FROM transactions_clean
) s
LATERAL VIEW stack(8,
    'customer_age (NULL)',                 s.m1,
    'gender (Unknown)',                    s.m2,
    'city (Unknown)',                      s.m3,
    'payment_method (Unknown)',            s.m4,
    'customer_rating (NULL)',              s.m5,
    'delivery_days (NULL)',                s.m6,
    'any string column blank',             s.m7,
    'transaction_value (NULL)',            s.m8
) x AS column_name, missing_or_unknown;

-- @output B9b_invalid_value_counts_clean.txt
SELECT
    SUM(CASE WHEN customer_age < 18 OR customer_age > 100 THEN 1 ELSE 0 END)                AS bad_age,
    SUM(CASE WHEN customer_rating < 1 OR customer_rating > 5 THEN 1 ELSE 0 END)             AS bad_rating,
    SUM(CASE WHEN quantity < 1 OR quantity > 5 THEN 1 ELSE 0 END)                           AS bad_quantity,
    SUM(CASE WHEN unit_price <= 0 THEN 1 ELSE 0 END)                                        AS bad_price,
    SUM(CASE WHEN order_status IN ('Completed','Returned') AND delivery_days < 1
             THEN 1 ELSE 0 END)                                                             AS bad_delivery_days
FROM transactions_clean;

-- @output B9c_distinct_values_clean.txt
SELECT column_name, clean_value, row_count
FROM (
    SELECT 'gender' AS column_name, gender AS clean_value, COUNT(*) AS row_count
    FROM transactions_clean GROUP BY gender
    UNION ALL
    SELECT 'city' AS column_name, city AS clean_value, COUNT(*) AS row_count
    FROM transactions_clean GROUP BY city
    UNION ALL
    SELECT 'payment_method' AS column_name, payment_method AS clean_value, COUNT(*) AS row_count
    FROM transactions_clean GROUP BY payment_method
    UNION ALL
    SELECT 'order_status' AS column_name, order_status AS clean_value, COUNT(*) AS row_count
    FROM transactions_clean GROUP BY order_status
) u
ORDER BY column_name, clean_value;

-- @output B9d_missing_by_status_clean.txt
SELECT
    order_status,
    COUNT(*)                                                 AS order_count,
    SUM(CASE WHEN customer_rating IS NULL THEN 1 ELSE 0 END) AS rating_missing,
    SUM(CASE WHEN delivery_days   IS NULL THEN 1 ELSE 0 END) AS delivery_days_missing
FROM transactions_clean
GROUP BY order_status
ORDER BY order_status;

-- @output B9e_raw_vs_clean_count.txt
SELECT r.raw_rows, c.clean_rows, r.raw_rows - c.clean_rows AS rows_dropped
FROM (SELECT COUNT(*) AS raw_rows   FROM transactions_raw)   r
CROSS JOIN (SELECT COUNT(*) AS clean_rows FROM transactions_clean) c;

-- B10. Table or view? A view stores only the SELECT, so every Part C query would re-read the raw
--      text file and re-run TRIM/INITCAP/CASE on every row; on billions of rows that cost is paid
--      again by every query. A table pays it once and stores the result as compressed, columnar ORC
--      that later queries scan quickly. A view is better only when the raw data changes constantly
--      and must always be reflected. Choice: TABLE (CTAS, ORC), rebuilt by re-running B8 after a load.

-- =====================================================================================
-- PART C : HIVEQL ANALYTICS  (revenue = Completed orders only, unless stated)
-- =====================================================================================

-- C1. Total revenue
-- @output C1_total_revenue.csv
SELECT SUM(transaction_value) AS total_revenue_inr
FROM transactions_clean
WHERE order_status = 'Completed';

-- C2. Total transactions, and split by order status
-- @output C2a_total_transactions.csv
SELECT COUNT(*) AS total_transactions
FROM transactions_clean;

-- @output C2b_orders_by_status.csv
SELECT
    order_status,
    order_count,
    ROUND(100 * order_count / SUM(order_count) OVER (), 2) AS pct_of_orders
FROM (
    SELECT order_status, COUNT(*) AS order_count
    FROM transactions_clean
    GROUP BY order_status
) s
ORDER BY order_count DESC;

-- C3. Top 10 product categories by revenue, with share of total revenue
-- @output C3_category_revenue.csv
SELECT
    product_category,
    completed_orders,
    revenue,
    ROUND(100 * revenue / SUM(revenue) OVER (), 2) AS revenue_share_pct
FROM (
    SELECT product_category,
           COUNT(*)               AS completed_orders,
           SUM(transaction_value) AS revenue
    FROM transactions_clean
    WHERE order_status = 'Completed'
    GROUP BY product_category
) c
ORDER BY revenue DESC
LIMIT 10;

-- C4. Top 10 products by revenue
-- @output C4_top_products.csv
SELECT
    product,
    product_category,
    SUM(quantity)          AS units_sold,
    SUM(transaction_value) AS revenue
FROM transactions_clean
WHERE order_status = 'Completed'
GROUP BY product, product_category
ORDER BY revenue DESC
LIMIT 10;

-- C5. Monthly revenue trend. 'yyyy-MM' keeps year and month together, so January 2024 and
--     January 2025 stay separate (grouping by MONTH() alone would merge them).
-- @output C5_monthly_revenue.csv
SELECT
    DATE_FORMAT(transaction_date, 'yyyy-MM') AS order_month,
    COUNT(*)                                 AS completed_orders,
    SUM(transaction_value)                   AS revenue
FROM transactions_clean
WHERE order_status = 'Completed'
GROUP BY DATE_FORMAT(transaction_date, 'yyyy-MM')
ORDER BY order_month;

-- C5b. Revenue by year and year-on-year growth (LAG over the yearly totals)
-- @output C5b_yearly_revenue.csv
SELECT
    order_year,
    completed_orders,
    revenue,
    ROUND(100 * (revenue - LAG(revenue) OVER (ORDER BY order_year))
          / LAG(revenue) OVER (ORDER BY order_year), 2) AS yoy_growth_pct
FROM (
    SELECT YEAR(transaction_date)  AS order_year,
           COUNT(*)                AS completed_orders,
           SUM(transaction_value)  AS revenue
    FROM transactions_clean
    WHERE order_status = 'Completed'
    GROUP BY YEAR(transaction_date)
) y
ORDER BY order_year;

-- C6. Revenue by city. Share is of TOTAL revenue (C1); the 'Unknown' city group is computed
--     but listed separately in C6b, so C6 shows the 14 real cities.
-- @output C6_city_revenue.csv
SELECT city, completed_orders, revenue, revenue_share_pct
FROM (
    SELECT
        city,
        completed_orders,
        revenue,
        ROUND(100 * revenue / SUM(revenue) OVER (), 2) AS revenue_share_pct
    FROM (
        SELECT city, COUNT(*) AS completed_orders, SUM(transaction_value) AS revenue
        FROM transactions_clean
        WHERE order_status = 'Completed'
        GROUP BY city
    ) g
) s
WHERE city <> 'Unknown'
ORDER BY revenue DESC;

-- @output C6b_unknown_city_revenue.csv
SELECT city, COUNT(*) AS completed_orders, SUM(transaction_value) AS revenue
FROM transactions_clean
WHERE order_status = 'Completed' AND city = 'Unknown'
GROUP BY city;

-- C7. Average order value (AOV) by city = average transaction_value of Completed orders.
--     The two ranks answer "is the highest-revenue city also the highest-AOV city?"
-- @output C7_city_avg_order_value.csv
SELECT
    city,
    completed_orders,
    avg_order_value,
    RANK() OVER (ORDER BY avg_order_value DESC) AS aov_rank,
    RANK() OVER (ORDER BY revenue DESC)         AS revenue_rank
FROM (
    SELECT city,
           COUNT(*)                         AS completed_orders,
           ROUND(AVG(transaction_value), 2) AS avg_order_value,
           SUM(transaction_value)           AS revenue
    FROM transactions_clean
    WHERE order_status = 'Completed' AND city <> 'Unknown'
    GROUP BY city
) c
ORDER BY avg_order_value DESC;

-- C8. Payment method frequency over ALL orders (a customer chooses a method when ordering,
--     whatever happens to the order later). Missing methods form their own 'Unknown' row and
--     stay in the denominator, so the percentages add up to 100.
-- @output C8_payment_methods.csv
SELECT
    payment_method,
    order_count,
    ROUND(100 * order_count / SUM(order_count) OVER (), 2) AS pct_of_orders
FROM (
    SELECT payment_method, COUNT(*) AS order_count
    FROM transactions_clean
    GROUP BY payment_method
) p
ORDER BY order_count DESC;

-- C9. Cancellation and return percentages
-- @output C9_cancel_return_rates.csv
SELECT
    COUNT(*)                                                             AS total_orders,
    SUM(CASE WHEN order_status = 'Cancelled' THEN 1 ELSE 0 END)          AS cancelled_orders,
    SUM(CASE WHEN order_status = 'Returned'  THEN 1 ELSE 0 END)          AS returned_orders,
    ROUND(100 * SUM(CASE WHEN order_status = 'Cancelled' THEN 1 ELSE 0 END) / COUNT(*), 2)
                                                                         AS cancellation_rate_pct,
    ROUND(100 * SUM(CASE WHEN order_status = 'Returned'  THEN 1 ELSE 0 END) / COUNT(*), 2)
                                                                         AS return_rate_pct,
    ROUND(100 * SUM(CASE WHEN order_status IN ('Cancelled','Returned') THEN 1 ELSE 0 END) / COUNT(*), 2)
                                                                         AS combined_rate_pct
FROM transactions_clean;

-- C10. Return rate by category. HAVING keeps categories with at least 500 orders: at a return
--      rate near 8%, 500 orders gives a 95% margin of error of about +/-2.4 percentage points,
--      small enough to compare categories. (All 8 categories pass here; the rule protects
--      the query when it runs on new data with small or new categories.)
-- @output C10_category_return_rate.csv
SELECT
    product_category,
    COUNT(*)                                                   AS order_count,
    SUM(CASE WHEN order_status = 'Returned' THEN 1 ELSE 0 END) AS returned_orders,
    ROUND(100 * SUM(CASE WHEN order_status = 'Returned' THEN 1 ELSE 0 END) / COUNT(*), 2)
                                                               AS return_rate_pct
FROM transactions_clean
GROUP BY product_category
HAVING COUNT(*) >= 500
ORDER BY return_rate_pct DESC;

-- C11. Rating by category. AVG/MIN/MAX skip NULL, so unrated orders never count as 0;
--      COUNT(customer_rating) counts rated orders only (Completed and Returned orders carry ratings).
-- @output C11_category_ratings.csv
SELECT
    product_category,
    ROUND(AVG(customer_rating), 2) AS avg_rating,
    MIN(customer_rating)           AS min_rating,
    MAX(customer_rating)           AS max_rating,
    COUNT(customer_rating)         AS rated_orders
FROM transactions_clean
GROUP BY product_category
ORDER BY avg_rating DESC;

-- C12. Average delivery time by city: Completed and Returned orders only (both were delivered;
--      a Cancelled order has no delivery). NULL delivery_days are skipped by AVG.
-- @output C12_city_delivery_days.csv
SELECT
    city,
    COUNT(delivery_days)          AS delivered_orders,
    ROUND(AVG(delivery_days), 2)  AS avg_delivery_days
FROM transactions_clean
WHERE order_status IN ('Completed', 'Returned')
  AND city <> 'Unknown'
GROUP BY city
ORDER BY avg_delivery_days DESC;

-- C13. Cities whose average delivery time exceeds the overall average. The overall average comes
--      from a one-row subquery joined to every row; HAVING compares each city against it.
-- @output C13_slow_delivery_cities.csv
SELECT
    d.city,
    ROUND(AVG(d.delivery_days), 2)   AS avg_delivery_days,
    ROUND(o.overall_avg_days, 2)     AS overall_avg_days,
    ROUND(AVG(d.delivery_days) - o.overall_avg_days, 2) AS days_above_overall
FROM transactions_clean d
CROSS JOIN (
    SELECT AVG(delivery_days) AS overall_avg_days
    FROM transactions_clean
    WHERE order_status IN ('Completed', 'Returned')
) o
WHERE d.order_status IN ('Completed', 'Returned')
  AND d.city <> 'Unknown'
GROUP BY d.city, o.overall_avg_days
HAVING AVG(d.delivery_days) > o.overall_avg_days
ORDER BY avg_delivery_days DESC;

-- C14. Revenue by gender (including 'Unknown')
-- @output C14_gender_revenue.csv
SELECT
    gender,
    order_count,
    completed_orders,
    revenue,
    ROUND(100 * revenue / SUM(revenue) OVER (), 2) AS revenue_share_pct,
    ROUND(revenue / completed_orders, 2)            AS avg_order_value
FROM (
    SELECT
        gender,
        COUNT(*)                                                                 AS order_count,
        SUM(CASE WHEN order_status = 'Completed' THEN 1 ELSE 0 END)              AS completed_orders,
        SUM(CASE WHEN order_status = 'Completed' THEN transaction_value ELSE 0 END) AS revenue
    FROM transactions_clean
    GROUP BY gender
) g
ORDER BY revenue DESC;

-- C15. Purchasing behaviour by age band (labels sort in age order; 'Unknown' sorts last)
-- @output C15_age_band_behaviour.csv
SELECT
    age_band,
    COUNT(*)                                                                    AS order_count,
    SUM(CASE WHEN order_status = 'Completed' THEN 1 ELSE 0 END)                 AS completed_orders,
    SUM(CASE WHEN order_status = 'Completed' THEN transaction_value ELSE 0 END) AS revenue,
    ROUND(SUM(CASE WHEN order_status = 'Completed' THEN transaction_value ELSE 0 END)
          / SUM(CASE WHEN order_status = 'Completed' THEN 1 ELSE 0 END), 2)     AS avg_order_value
FROM (
    SELECT
        CASE
            WHEN customer_age IS NULL            THEN 'Unknown'
            WHEN customer_age BETWEEN 18 AND 24  THEN '18-24'
            WHEN customer_age BETWEEN 25 AND 34  THEN '25-34'
            WHEN customer_age BETWEEN 35 AND 44  THEN '35-44'
            WHEN customer_age BETWEEN 45 AND 54  THEN '45-54'
            WHEN customer_age BETWEEN 55 AND 64  THEN '55-64'
            ELSE '65-100'
        END AS age_band,
        order_status,
        transaction_value
    FROM transactions_clean
) a
GROUP BY age_band
ORDER BY age_band;

-- C16. Top 10 customers by total spending (Completed orders). Every customer has one real city, but
--      some of their orders have a blank city ('Unknown' after cleaning). Grouping by customer_id AND
--      city would split such a customer into two rows, so spend is grouped by customer_id alone and
--      the city is taken from the orders on which it was recorded.
-- @output C16_top_customers.csv
SELECT
    customer_id,
    COALESCE(MAX(CASE WHEN city <> 'Unknown' THEN city END), 'Unknown') AS city,
    COUNT(*)               AS completed_orders,
    SUM(transaction_value) AS total_spend
FROM transactions_clean
WHERE order_status = 'Completed'
GROUP BY customer_id
ORDER BY total_spend DESC
LIMIT 10;

-- C16b. How concentrated is spending? Share of revenue from the top 10 customers
-- @output C16b_top10_customer_share.csv
SELECT
    COUNT(*)                                            AS customers_with_completed_orders,
    SUM(CASE WHEN rnk <= 10 THEN spend ELSE 0 END)      AS top10_spend,
    SUM(spend)                                          AS total_revenue,
    ROUND(100 * SUM(CASE WHEN rnk <= 10 THEN spend ELSE 0 END) / SUM(spend), 2) AS top10_share_pct
FROM (
    SELECT customer_id, spend,
           ROW_NUMBER() OVER (ORDER BY spend DESC) AS rnk
    FROM (
        SELECT customer_id, SUM(transaction_value) AS spend
        FROM transactions_clean
        WHERE order_status = 'Completed'
        GROUP BY customer_id
    ) s
) c;

-- C17. Rating versus sales: a per-product rating summary JOINed to a per-product sales summary
-- @output C17_product_rating_vs_sales.csv
SELECT
    s.product,
    s.product_category,
    r.avg_rating,
    r.rated_orders,
    s.units_sold,
    s.revenue
FROM (
    SELECT product, product_category,
           SUM(quantity)          AS units_sold,
           SUM(transaction_value) AS revenue
    FROM transactions_clean
    WHERE order_status = 'Completed'
    GROUP BY product, product_category
) s
JOIN (
    SELECT product,
           ROUND(AVG(customer_rating), 2) AS avg_rating,
           COUNT(customer_rating)         AS rated_orders
    FROM transactions_clean
    WHERE customer_rating IS NOT NULL
    GROUP BY product
) r
ON s.product = r.product
ORDER BY r.avg_rating DESC, s.revenue DESC;

-- C17b. Correlation across the 44 products (same two summaries)
-- @output C17b_rating_sales_correlation.csv
SELECT
    COUNT(*)                                       AS products,
    ROUND(CORR(r.avg_rating, s.revenue), 4)        AS corr_rating_revenue,
    ROUND(CORR(r.avg_rating, s.units_sold), 4)     AS corr_rating_units
FROM (
    SELECT product,
           SUM(quantity)                            AS units_sold,
           CAST(SUM(transaction_value) AS DOUBLE)   AS revenue
    FROM transactions_clean
    WHERE order_status = 'Completed'
    GROUP BY product
) s
JOIN (
    SELECT product, AVG(customer_rating) AS avg_rating
    FROM transactions_clean
    WHERE customer_rating IS NOT NULL
    GROUP BY product
) r
ON s.product = r.product;

-- C17c. The same question at category level, plus rating against return rate (8 categories)
-- @output C17c_category_rating_correlation.csv
SELECT
    COUNT(*)                                          AS categories,
    ROUND(CORR(g.avg_rating, s.revenue), 4)           AS corr_rating_revenue,
    ROUND(CORR(g.avg_rating, r.return_rate), 4)       AS corr_rating_return_rate
FROM (
    SELECT product_category, AVG(customer_rating) AS avg_rating
    FROM transactions_clean
    GROUP BY product_category
) g
JOIN (
    SELECT product_category, CAST(SUM(transaction_value) AS DOUBLE) AS revenue
    FROM transactions_clean
    WHERE order_status = 'Completed'
    GROUP BY product_category
) s ON g.product_category = s.product_category
JOIN (
    SELECT product_category,
           AVG(CASE WHEN order_status = 'Returned' THEN CAST(1 AS DOUBLE) ELSE CAST(0 AS DOUBLE) END) AS return_rate
    FROM transactions_clean
    GROUP BY product_category
) r ON g.product_category = r.product_category;

-- C18. High volume, low revenue. Cut-offs: units sold ABOVE the average units per product AND
--      revenue BELOW the average revenue per product (both averages over the 44 products,
--      Completed orders), computed in a one-row subquery and applied in HAVING. SUM(quantity)
--      is BIGINT and the average is DOUBLE, so the sum is cast to DOUBLE for a type-safe compare.
-- @output C18_high_volume_low_revenue.csv
SELECT
    t.product,
    t.product_category,
    SUM(t.quantity)                AS units_sold,
    SUM(t.transaction_value)       AS revenue,
    ROUND(a.avg_units_per_product, 2)   AS cutoff_units,
    ROUND(a.avg_revenue_per_product, 2) AS cutoff_revenue
FROM transactions_clean t
CROSS JOIN (
    SELECT AVG(units_sold) AS avg_units_per_product,
           AVG(revenue)    AS avg_revenue_per_product
    FROM (
        SELECT product, SUM(quantity) AS units_sold, SUM(transaction_value) AS revenue
        FROM transactions_clean
        WHERE order_status = 'Completed'
        GROUP BY product
    ) p
) a
WHERE t.order_status = 'Completed'
GROUP BY t.product, t.product_category, a.avg_units_per_product, a.avg_revenue_per_product
HAVING CAST(SUM(t.quantity) AS DOUBLE) > a.avg_units_per_product
   AND SUM(t.transaction_value) < a.avg_revenue_per_product
ORDER BY units_sold DESC;

-- C19. High revenue, low volume: revenue ABOVE the average revenue per product AND units sold
--      BELOW the average units per product (same cut-offs as C18).
-- @output C19_high_revenue_low_volume.csv
SELECT
    t.product,
    t.product_category,
    SUM(t.quantity)                AS units_sold,
    SUM(t.transaction_value)       AS revenue,
    ROUND(a.avg_units_per_product, 2)   AS cutoff_units,
    ROUND(a.avg_revenue_per_product, 2) AS cutoff_revenue
FROM transactions_clean t
CROSS JOIN (
    SELECT AVG(units_sold) AS avg_units_per_product,
           AVG(revenue)    AS avg_revenue_per_product
    FROM (
        SELECT product, SUM(quantity) AS units_sold, SUM(transaction_value) AS revenue
        FROM transactions_clean
        WHERE order_status = 'Completed'
        GROUP BY product
    ) p
) a
WHERE t.order_status = 'Completed'
GROUP BY t.product, t.product_category, a.avg_units_per_product, a.avg_revenue_per_product
HAVING SUM(t.transaction_value) > a.avg_revenue_per_product
   AND CAST(SUM(t.quantity) AS DOUBLE) < a.avg_units_per_product
ORDER BY revenue DESC;

-- C20. Highest-revenue month overall
-- @output C20a_best_month_overall.csv
SELECT
    DATE_FORMAT(transaction_date, 'yyyy-MM') AS order_month,
    SUM(transaction_value)                   AS revenue
FROM transactions_clean
WHERE order_status = 'Completed'
GROUP BY DATE_FORMAT(transaction_date, 'yyyy-MM')
ORDER BY revenue DESC
LIMIT 1;

-- C20b. Highest-revenue month within each year (ROW_NUMBER per year)
-- @output C20b_best_month_per_year.csv
SELECT order_year, order_month, revenue
FROM (
    SELECT
        order_year,
        order_month,
        revenue,
        ROW_NUMBER() OVER (PARTITION BY order_year ORDER BY revenue DESC) AS rn
    FROM (
        SELECT
            YEAR(transaction_date)                   AS order_year,
            DATE_FORMAT(transaction_date, 'yyyy-MM') AS order_month,
            SUM(transaction_value)                   AS revenue
        FROM transactions_clean
        WHERE order_status = 'Completed'
        GROUP BY YEAR(transaction_date), DATE_FORMAT(transaction_date, 'yyyy-MM')
    ) m
) ranked
WHERE rn = 1
ORDER BY order_year;

-- C20c. Share of each year's revenue earned in October-December (festive season)
-- @output C20c_festive_quarter_share.csv
SELECT
    YEAR(transaction_date) AS order_year,
    SUM(CASE WHEN MONTH(transaction_date) >= 10 THEN transaction_value ELSE 0 END) AS oct_dec_revenue,
    SUM(transaction_value)                                                         AS year_revenue,
    ROUND(100 * SUM(CASE WHEN MONTH(transaction_date) >= 10 THEN transaction_value ELSE 0 END)
          / SUM(transaction_value), 2)                                             AS oct_dec_share_pct
FROM transactions_clean
WHERE order_status = 'Completed'
GROUP BY YEAR(transaction_date)
ORDER BY order_year;

-- =====================================================================================
-- PART D : EXPORTS FOR VISUALISATION (Method 2: INSERT OVERWRITE LOCAL DIRECTORY)
-- Hive writes no header row; the notebook adds the column names listed in each comment.
-- =====================================================================================

-- V1 <- C5  columns: order_month, completed_orders, revenue
-- @output D_V1_export.txt
INSERT OVERWRITE LOCAL DIRECTORY '${hivevar:export_dir}/V1_monthly_revenue'
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
SELECT
    DATE_FORMAT(transaction_date, 'yyyy-MM') AS order_month,
    COUNT(*)                                 AS completed_orders,
    SUM(transaction_value)                   AS revenue
FROM transactions_clean
WHERE order_status = 'Completed'
GROUP BY DATE_FORMAT(transaction_date, 'yyyy-MM')
ORDER BY order_month;

-- V2 <- C3  columns: product_category, completed_orders, revenue, revenue_share_pct
-- @output D_V2_export.txt
INSERT OVERWRITE LOCAL DIRECTORY '${hivevar:export_dir}/V2_category_revenue'
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
SELECT
    product_category,
    completed_orders,
    revenue,
    ROUND(100 * revenue / SUM(revenue) OVER (), 2) AS revenue_share_pct
FROM (
    SELECT product_category,
           COUNT(*)               AS completed_orders,
           SUM(transaction_value) AS revenue
    FROM transactions_clean
    WHERE order_status = 'Completed'
    GROUP BY product_category
) c
ORDER BY revenue DESC
LIMIT 10;

-- V3 <- C6  columns: city, completed_orders, revenue, revenue_share_pct
-- @output D_V3_export.txt
INSERT OVERWRITE LOCAL DIRECTORY '${hivevar:export_dir}/V3_city_revenue'
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
SELECT city, completed_orders, revenue, revenue_share_pct
FROM (
    SELECT
        city,
        completed_orders,
        revenue,
        ROUND(100 * revenue / SUM(revenue) OVER (), 2) AS revenue_share_pct
    FROM (
        SELECT city, COUNT(*) AS completed_orders, SUM(transaction_value) AS revenue
        FROM transactions_clean
        WHERE order_status = 'Completed'
        GROUP BY city
    ) g
) s
WHERE city <> 'Unknown'
ORDER BY revenue DESC;

-- V4 <- C8  columns: payment_method, order_count, pct_of_orders
-- @output D_V4_export.txt
INSERT OVERWRITE LOCAL DIRECTORY '${hivevar:export_dir}/V4_payment_methods'
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
SELECT
    payment_method,
    order_count,
    ROUND(100 * order_count / SUM(order_count) OVER (), 2) AS pct_of_orders
FROM (
    SELECT payment_method, COUNT(*) AS order_count
    FROM transactions_clean
    GROUP BY payment_method
) p
ORDER BY order_count DESC;

-- V5 <- C2b  columns: order_status, order_count, pct_of_orders
-- @output D_V5_export.txt
INSERT OVERWRITE LOCAL DIRECTORY '${hivevar:export_dir}/V5_order_status'
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
SELECT
    order_status,
    order_count,
    ROUND(100 * order_count / SUM(order_count) OVER (), 2) AS pct_of_orders
FROM (
    SELECT order_status, COUNT(*) AS order_count
    FROM transactions_clean
    GROUP BY order_status
) s
ORDER BY order_count DESC;

-- V6 <- C10 + C11 joined: does a category's rating explain its return rate?
--       columns: product_category, order_count, return_rate_pct, avg_rating, revenue_share_pct
-- @output D_V6_export.txt
INSERT OVERWRITE LOCAL DIRECTORY '${hivevar:export_dir}/V6_category_returns_vs_rating'
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
SELECT
    r.product_category,
    r.order_count,
    r.return_rate_pct,
    g.avg_rating,
    s.revenue_share_pct
FROM (
    SELECT product_category,
           COUNT(*) AS order_count,
           ROUND(100 * SUM(CASE WHEN order_status = 'Returned' THEN 1 ELSE 0 END) / COUNT(*), 2) AS return_rate_pct
    FROM transactions_clean
    GROUP BY product_category
) r
JOIN (
    SELECT product_category, ROUND(AVG(customer_rating), 2) AS avg_rating
    FROM transactions_clean
    GROUP BY product_category
) g ON r.product_category = g.product_category
JOIN (
    SELECT product_category,
           ROUND(100 * revenue / SUM(revenue) OVER (), 2) AS revenue_share_pct
    FROM (
        SELECT product_category, SUM(transaction_value) AS revenue
        FROM transactions_clean
        WHERE order_status = 'Completed'
        GROUP BY product_category
    ) c
) s ON r.product_category = s.product_category
ORDER BY r.return_rate_pct DESC;

-- =====================================================================================
-- BIG DATA PERSPECTIVE : execution plan, storage formats, partitioning
-- =====================================================================================

-- BD1. Execution plan of C3: how one GROUP BY + ORDER BY becomes MapReduce stages
-- @output BD1_explain_c3.txt
EXPLAIN
SELECT
    product_category,
    completed_orders,
    revenue,
    ROUND(100 * revenue / SUM(revenue) OVER (), 2) AS revenue_share_pct
FROM (
    SELECT product_category,
           COUNT(*)               AS completed_orders,
           SUM(transaction_value) AS revenue
    FROM transactions_clean
    WHERE order_status = 'Completed'
    GROUP BY product_category
) c
ORDER BY revenue DESC
LIMIT 10;

-- BD2. Storage: the same 15,000 rows as TEXTFILE (raw) and as ORC (clean)
-- @output BD2_storage_raw.txt
ANALYZE TABLE transactions_raw COMPUTE STATISTICS;
SHOW TBLPROPERTIES transactions_raw;

-- @output BD2_storage_clean.txt
ANALYZE TABLE transactions_clean COMPUTE STATISTICS;
SHOW TBLPROPERTIES transactions_clean;

-- BD3. Partitioning: the clean data partitioned by year and month (dynamic partitions)
-- @output BD3_partitions.txt
SET hive.exec.dynamic.partition=true;
SET hive.exec.dynamic.partition.mode=nonstrict;
DROP TABLE IF EXISTS transactions_by_month;
CREATE TABLE transactions_by_month (
    transaction_id    STRING,
    transaction_date  DATE,
    customer_id       STRING,
    customer_age      INT,
    gender            STRING,
    city              STRING,
    product_category  STRING,
    product           STRING,
    quantity          INT,
    unit_price        DECIMAL(10,2),
    payment_method    STRING,
    order_status      STRING,
    customer_rating   INT,
    delivery_days     INT,
    transaction_value DECIMAL(12,2)
)
PARTITIONED BY (order_year INT, order_month INT)
STORED AS ORC;
INSERT OVERWRITE TABLE transactions_by_month PARTITION (order_year, order_month)
SELECT
    transaction_id, transaction_date, customer_id, customer_age, gender, city,
    product_category, product, quantity, unit_price, payment_method, order_status,
    customer_rating, delivery_days, transaction_value,
    YEAR(transaction_date)  AS order_year,
    MONTH(transaction_date) AS order_month
FROM transactions_clean;
SHOW PARTITIONS transactions_by_month;

-- BD4. Partition pruning: a query on one month reads one partition directory, not all 24
-- @output BD4_explain_dependency.txt
EXPLAIN DEPENDENCY
SELECT SUM(transaction_value) AS revenue
FROM transactions_by_month
WHERE order_year = 2025 AND order_month = 11 AND order_status = 'Completed';

-- @output BD4_pruned_query_result.txt
SELECT SUM(transaction_value) AS revenue_2025_11
FROM transactions_by_month
WHERE order_year = 2025 AND order_month = 11 AND order_status = 'Completed';

-- ============================================ end of script ==========================
