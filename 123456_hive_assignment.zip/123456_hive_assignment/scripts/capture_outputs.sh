#!/bin/bash
# ---------------------------------------------------------------------------------------
# capture_outputs.sh  -  saves the output of every numbered query in outputs/
#
# The HiveQL script marks each query with a line "-- @output <file name>". This script
# cuts hql/123456_assignment.hql at those markers and runs each piece with the Hive CLI.
# Everything before the first marker (paths, SET statements, CREATE DATABASE, USE) is
# run silently in front of every piece, so each piece sees the same session state.
#
#   *.csv  -> result rows, tab separators replaced by commas (header row included)
#   *.txt  -> console output as printed by Hive
#   A3_*, B8a_*, D_* and BD3_* files also keep Hive's progress messages (load, CTAS,
#   export and partition-insert evidence)
#
# Usage (from the project folder):  bash scripts/capture_outputs.sh
# ---------------------------------------------------------------------------------------
set -euo pipefail
cd "$(dirname "$0")/.."

HQL=hql/123456_assignment.hql
OUT=outputs
WORK=$(mktemp -d)
trap 'rm -rf "$WORK"' EXIT
mkdir -p "$OUT"

# A5 cross-check: line count of the source file (header line included)
wc -l data/ecommerce_transactions.csv > "$OUT/A5_csv_line_count.txt"

awk -v dir="$WORK" '
  /^-- @output / { n++; file = sprintf("%s/%03d_%s", dir, n, $3); next }
  n == 0         { print > (dir "/prelude.hql"); next }
                 { print > file }
' "$HQL"

for piece in "$WORK"/[0-9][0-9][0-9]_*; do
    name=$(basename "$piece"); name=${name#*_}
    {
        echo "SET hive.session.silent=true;"
        cat "$WORK/prelude.hql"
        if [[ $name == A3_* || $name == B8a_* || $name == D_* || $name == BD3_* ]]; then echo "SET hive.session.silent=false;"; fi
        cat "$piece"
    } > "$WORK/run.hql"

    printf '%-40s' "$name"
    start=$(date +%s)
    if [[ $name == A3_* || $name == B8a_* || $name == D_* || $name == BD3_* ]]; then
        hive -f "$WORK/run.hql" > "$OUT/$name" 2>&1
    elif [[ $name == *.csv ]]; then
        hive -f "$WORK/run.hql" 2> "$WORK/err.txt" | tr '\t' ',' > "$OUT/$name"
    else
        hive -f "$WORK/run.hql" > "$OUT/$name" 2> "$WORK/err.txt"
    fi
    echo "done ($(( $(date +%s) - start )) s)"
done
